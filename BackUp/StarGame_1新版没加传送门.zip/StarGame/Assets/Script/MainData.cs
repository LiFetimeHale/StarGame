﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[Serializable]
public class Transfer
{
    public Vector2 from;
    public Vector2 to;
}

[Serializable]
public class GameData
{
    public int col = 5;
    public int row = 5;

    public Vector2 littleStarPos;
    public Vector2 bigStarPos;

    public List<Vector2> obstacleList = new List<Vector2>();

    public List<Transfer> transferList = new List<Transfer>();
}

public static class DataName
{
    public const string UnlockedCheckpoint = "UnlockedCheckpoint";
}

public class MainData : MonoBehaviour
{
    private static MainData m_Instance;
    public static MainData Instance
    {
        get { return m_Instance; }
    }

    public List<GameData> gameDatas = new List<GameData>();

    private int m_CurCheckpoint = -1;
    public int CurCheckpoint
    {
        get 
        {
            if (m_CurCheckpoint == -1)
            {
                if (PlayerPrefs.HasKey(DataName.UnlockedCheckpoint))
                {
                    m_CurCheckpoint = PlayerPrefs.GetInt(DataName.UnlockedCheckpoint);
                }
                else
                {
                    m_CurCheckpoint = 1;
                    PlayerPrefs.SetInt(DataName.UnlockedCheckpoint, 1);
                }
            }

            return m_CurCheckpoint; 
        }

        set { m_CurCheckpoint = value; }
    }

    public int MaxCheckpoint
    {
        get{ return gameDatas.Count; }
    }

    void Awake()
    {
        m_Instance = this;
        DontDestroyOnLoad(gameObject); 
    }

    void OnDestory()
    {
        m_Instance = null;
    }
}
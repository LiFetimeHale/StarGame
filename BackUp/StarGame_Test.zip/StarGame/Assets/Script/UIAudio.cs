﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UIAudio : MonoBehaviour 
{
    public List<AudioClip> audioList = new List<AudioClip>();
}
